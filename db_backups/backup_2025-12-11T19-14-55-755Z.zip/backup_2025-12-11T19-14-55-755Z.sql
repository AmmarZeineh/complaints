-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: complaint
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaint` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `governmentId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `documents` text COLLATE utf8mb4_unicode_ci,
  `status` enum('NEW','INPROCESS','COMPLETED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  `employeeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Complaint_userId_fkey` (`userId`),
  KEY `Complaint_governmentId_fkey` (`governmentId`),
  CONSTRAINT `Complaint_governmentId_fkey` FOREIGN KEY (`governmentId`) REFERENCES `government` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Complaint_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint`
--

LOCK TABLES `complaint` WRITE;
/*!40000 ALTER TABLE `complaint` DISABLE KEYS */;
INSERT INTO `complaint` VALUES (1,2,1,'dfghj','homs','dfghg','[\"http://localhost:3000/uploads/2/complaints/1/images/1764784423114_0_photo_2024_11_03_06_28_22__2__jpg.jpg\"]','[\"http://localhost:3000/uploads/2/complaints/1/documents/1764784423116_0_W03_Web_XSS_pptx_pdf.pdf\"]','INPROCESS','2025-12-03 17:53:43.083','2025-12-03 17:56:10.877',NULL,5),(2,2,1,'ss','stringss','sss','[\"http://localhost:3000/uploads/2/complaints/2/images/1764799803071_0_photo_2024_11_03_06_28_22__2__jpg.jpg\"]',NULL,'REJECTED','2025-12-03 22:10:03.022','2025-12-03 22:11:58.178',NULL,6),(3,2,2,'ASD','string','string','[]','[]','NEW','2025-12-08 22:23:22.235','2025-12-08 23:22:01.092',NULL,7),(4,2,2,'string','string','string',NULL,NULL,'REJECTED','2025-12-08 23:13:55.816','2025-12-08 23:15:34.215',NULL,7);
/*!40000 ALTER TABLE `complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complainthistory`
--

DROP TABLE IF EXISTS `complainthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complainthistory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `complaintId` int NOT NULL,
  `userId` int NOT NULL,
  `action` enum('COMPLAINT_CREATED','COMPLAINT_UPDATED','COMPLAINT_ASSIGNED','STATUS_CHANGED','NOTE_ADDED','INTERACTION_CREATED','COMPLAINT_DELETED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldValue` text COLLATE utf8mb4_unicode_ci,
  `newValue` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ComplaintHistory_complaintId_idx` (`complaintId`),
  KEY `ComplaintHistory_userId_idx` (`userId`),
  KEY `ComplaintHistory_action_idx` (`action`),
  KEY `ComplaintHistory_createdAt_idx` (`createdAt`),
  CONSTRAINT `ComplaintHistory_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ComplaintHistory_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complainthistory`
--

LOCK TABLES `complainthistory` WRITE;
/*!40000 ALTER TABLE `complainthistory` DISABLE KEYS */;
INSERT INTO `complainthistory` VALUES (1,2,2,'COMPLAINT_CREATED',NULL,'{\"type\":\"ss\",\"description\":\"sss\",\"location\":\"stringss\",\"governmentId\":1}','تم إنشاء الشكوى','null','2025-12-03 22:10:03.101',NULL),(2,2,6,'COMPLAINT_ASSIGNED',NULL,'{\"employeeId\":6,\"employeeName\":\"fgh\"}','تم حجز الشكوى بواسطة fgh','null','2025-12-03 22:11:47.142',NULL),(3,2,6,'STATUS_CHANGED','{\"status\":\"NEW\"}','{\"status\":\"REJECTED\"}','تم تغيير الحالة من \"جديدة\" إلى \"مرفوضة\"','null','2025-12-03 22:11:58.193',NULL),(4,2,6,'NOTE_ADDED',NULL,'{\"noteContent\":\"sdfghjkjhgf...\"}','تم إضافة ملاحظة جديدة','{\"noteId\": 1}','2025-12-03 22:14:14.290',NULL),(5,2,6,'INTERACTION_CREATED',NULL,'{\"type\":\"REQUEST_INFO\",\"message\":\"dsdxdfg...\"}','طلب معلومات إضافية','{\"interactionId\": 1}','2025-12-03 22:16:21.808',NULL),(6,2,6,'INTERACTION_CREATED',NULL,'{\"type\":\"CITIZEN_RESPONSE\",\"message\":\"dsdxdfgj...\"}','رد المواطن','{\"interactionId\": 2}','2025-12-03 22:17:53.920',NULL),(7,3,2,'COMPLAINT_CREATED',NULL,'{\"type\":\"fghjg\",\"description\":\"dfghjhg\",\"location\":\"fgf\",\"governmentId\":2}','تم إنشاء الشكوى','null','2025-12-08 22:23:22.366',NULL),(8,3,7,'COMPLAINT_ASSIGNED',NULL,'{\"employeeId\":7,\"employeeName\":\"fgh\"}','تم حجز الشكوى بواسطة fgh','null','2025-12-08 22:24:56.965',NULL),(9,4,2,'COMPLAINT_CREATED',NULL,'{\"type\":\"string\",\"description\":\"string\",\"location\":\"string\",\"governmentId\":2}','تم إنشاء الشكوى','null','2025-12-08 23:13:56.130',NULL),(10,4,7,'COMPLAINT_ASSIGNED',NULL,'{\"employeeId\":7,\"employeeName\":\"fgh\"}','تم حجز الشكوى بواسطة fgh','null','2025-12-08 23:14:21.876',NULL),(11,4,7,'STATUS_CHANGED','{\"status\":\"INPROCESS\"}','{\"status\":\"REJECTED\"}','تم تغيير الحالة من \"قيد المعالجة\" إلى \"مرفوضة\"','null','2025-12-08 23:15:34.202',NULL),(12,3,2,'COMPLAINT_UPDATED','{\"description\":\"dfghjhg\",\"location\":\"fgf\",\"type\":\"fghjg\"}','{\"description\":\"string\",\"location\":\"string\",\"type\":\"ASD\"}','تم تعديل: الوصف، الموقع، النوع','null','2025-12-08 23:22:01.121',NULL);
/*!40000 ALTER TABLE `complainthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaintinteraction`
--

DROP TABLE IF EXISTS `complaintinteraction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaintinteraction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `complaintId` int NOT NULL,
  `senderId` int NOT NULL,
  `receiverId` int DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('REQUEST_INFO','CITIZEN_RESPONSE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `documents` text COLLATE utf8mb4_unicode_ci,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ComplaintInteraction_complaintId_idx` (`complaintId`),
  KEY `ComplaintInteraction_senderId_idx` (`senderId`),
  KEY `ComplaintInteraction_receiverId_fkey` (`receiverId`),
  CONSTRAINT `ComplaintInteraction_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ComplaintInteraction_receiverId_fkey` FOREIGN KEY (`receiverId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ComplaintInteraction_senderId_fkey` FOREIGN KEY (`senderId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaintinteraction`
--

LOCK TABLES `complaintinteraction` WRITE;
/*!40000 ALTER TABLE `complaintinteraction` DISABLE KEYS */;
INSERT INTO `complaintinteraction` VALUES (1,2,6,2,'dsdxdfg','REQUEST_INFO','[\"http://localhost:3000/uploads/2/complaints/2/interactions/1/images/1764800181794_0_photo_2024_11_03_06_28_22__2__jpg.jpg\"]',NULL,0,'2025-12-03 22:16:21.785','2025-12-03 22:16:21.797',NULL),(2,2,6,2,'dsdxdfgj','CITIZEN_RESPONSE','[\"http://localhost:3000/uploads/2/complaints/2/interactions/2/images/1764800273912_0_photo_2024_11_03_06_28_22__2__jpg.jpg\"]',NULL,0,'2025-12-03 22:17:53.903','2025-12-03 22:17:53.914',NULL);
/*!40000 ALTER TABLE `complaintinteraction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaintnote`
--

DROP TABLE IF EXISTS `complaintnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaintnote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `complaintId` int NOT NULL,
  `userId` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ComplaintNote_complaintId_idx` (`complaintId`),
  KEY `ComplaintNote_userId_idx` (`userId`),
  CONSTRAINT `ComplaintNote_complaintId_fkey` FOREIGN KEY (`complaintId`) REFERENCES `complaint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ComplaintNote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaintnote`
--

LOCK TABLES `complaintnote` WRITE;
/*!40000 ALTER TABLE `complaintnote` DISABLE KEYS */;
INSERT INTO `complaintnote` VALUES (1,2,6,'sdfghjkjhgf','2025-12-03 22:14:14.276','2025-12-03 22:14:14.276',NULL);
/*!40000 ALTER TABLE `complaintnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailverification`
--

DROP TABLE IF EXISTS `emailverification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emailverification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailverification`
--

LOCK TABLES `emailverification` WRITE;
/*!40000 ALTER TABLE `emailverification` DISABLE KEYS */;
INSERT INTO `emailverification` VALUES (1,'hb@gmail.com','573908','2025-12-03 17:57:24.127','2025-12-03 17:47:24.154','2025-12-03 17:48:35.324','2025-12-03 17:48:35.322'),(2,'hikhb@gmail.com','433717','2025-12-03 17:57:58.048','2025-12-03 17:47:58.057','2025-12-03 17:47:58.057',NULL);
/*!40000 ALTER TABLE `emailverification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `government`
--

DROP TABLE IF EXISTS `government`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `government` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Government_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `government`
--

LOCK TABLES `government` WRITE;
/*!40000 ALTER TABLE `government` DISABLE KEYS */;
INSERT INTO `government` VALUES (1,'dfghj','2025-12-03 17:50:38.992','2025-12-03 17:50:38.992',NULL),(2,'dfghjhj','2025-12-03 17:50:46.216','2025-12-03 17:50:46.216',NULL);
/*!40000 ALTER TABLE `government` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Notification_userId_fkey` (`userId`),
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,2,'تم استلام الشكوى الخاصة بك','تم استلام شكواك رقم 1 من قبل الموظف وهي الآن قيد المعالجة.','COMPLAINT_ASSIGNED','{\"complaintId\": 1}',0,'2025-12-03 17:55:58.534','2025-12-03 17:55:58.534',NULL),(2,2,'تغيير الحالة للشكوى الخاصة بك','تم تغيير حالة الشكوى الخاصة بك إلى: INPROCESS','COMPLAINT_STATUS_CHANGED','{\"newStatus\": \"INPROCESS\", \"complaintId\": 1}',0,'2025-12-03 17:56:10.867','2025-12-03 17:56:10.867',NULL),(3,2,'تم استلام تفاعل جديد على الشكوى الخاصة بك','لديك تفاعل جديد على الشكوى رقم 2: \"dsdxdfg\"','COMPLAINT_INTERACTION','{\"complaintId\": 2, \"interactionId\": 1}',0,'2025-12-03 22:16:24.888','2025-12-03 22:16:24.888',NULL),(4,2,'تم استلام تفاعل جديد على الشكوى الخاصة بك','لديك تفاعل جديد على الشكوى رقم 2: \"dsdxdfgj\"','COMPLAINT_INTERACTION','{\"complaintId\": 2, \"interactionId\": 2}',0,'2025-12-03 22:17:55.022','2025-12-03 22:17:55.022',NULL),(5,2,'تم استلام الشكوى الخاصة بك','تم استلام شكواك رقم 4 من قبل الموظف وهي الآن قيد المعالجة.','COMPLAINT_ASSIGNED','{\"complaintId\": 4}',0,'2025-12-08 23:14:21.839','2025-12-08 23:14:21.839',NULL),(6,2,'تغيير الحالة للشكوى الخاصة بك','تم تغيير حالة الشكوى الخاصة بك إلى: REJECTED','COMPLAINT_STATUS_CHANGED','{\"newStatus\": \"REJECTED\", \"complaintId\": 4}',0,'2025-12-08 23:15:34.187','2025-12-08 23:15:34.187',NULL),(7,2,'قفل الحساب مؤقتًا','تم قفل حسابك مؤقتًا لمدة 15 دقيقة بسبب تعدد محاولات الدخول غير الناجحة.','ACCOUNT_LOCKED','{\"lockedUntil\": \"2025-12-11T17:59:05.047Z\", \"failedAttempts\": 5}',0,'2025-12-11 17:44:05.260','2025-12-11 17:44:05.260',NULL),(8,4,'قفل الحساب مؤقتًا','تم قفل حسابك مؤقتًا لمدة 15 دقيقة بسبب تعدد محاولات الدخول غير الناجحة.','ACCOUNT_LOCKED','{\"lockedUntil\": \"2025-12-11T18:02:22.396Z\", \"failedAttempts\": 5}',0,'2025-12-11 17:47:22.594','2025-12-11 17:47:22.594',NULL),(9,6,'قفل الحساب مؤقتًا','تم قفل حسابك مؤقتًا لمدة 15 دقيقة بسبب تعدد محاولات الدخول غير الناجحة.','ACCOUNT_LOCKED','{\"lockedUntil\": \"2025-12-11T18:03:48.570Z\", \"failedAttempts\": 5}',0,'2025-12-11 17:48:48.794','2025-12-11 17:48:48.794',NULL);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Permission_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'UPDATE_STATUS','2025-11-30 12:51:08.208','2025-11-30 12:51:08.208',NULL),(2,'CREATE_NOTE','2025-11-30 12:51:08.208','2025-11-30 12:51:08.208',NULL),(3,'ADD_REQUEST','2025-11-30 12:51:08.208','2025-11-30 12:51:08.208',NULL),(4,'export_complaint_history','2025-12-10 21:32:21.182','2025-12-10 21:32:21.182',NULL);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationalID` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `governmentId` int DEFAULT NULL,
  `roleId` int NOT NULL,
  `isEmailVerified` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  `failedLoginAttempts` int NOT NULL DEFAULT '0',
  `lastLoginAttemptAt` datetime(3) DEFAULT NULL,
  `lockedUntil` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_nationalID_key` (`nationalID`),
  KEY `User_governmentId_fkey` (`governmentId`),
  KEY `User_roleId_fkey` (`roleId`),
  CONSTRAINT `User_governmentId_fkey` FOREIGN KEY (`governmentId`) REFERENCES `government` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `userrole` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Super Admin','0000000000','superadmin@example.com','$2b$10$2ggdbxIwIlE9NiMhUT8hLuifHnSlRBMOriHUNWoaryXmh/nX7ujjG',NULL,1,1,'2025-11-30 12:52:43.522','2025-11-30 12:52:43.522',NULL,0,NULL,NULL),(2,'ediied','12345678','hb@gmail.com','$2b$10$rxikgMiDHFiCyozARy7Bs.QD/pNwkRuKxzr3Se6z6W9rmOtTC0AE2',NULL,3,1,'2025-12-03 17:47:24.087','2025-12-11 17:59:55.124',NULL,0,'2025-12-11 17:59:54.902',NULL),(4,'oki','123i45678','hikhb@gmail.com','$2b$10$6JbPKtNLDadOzqh0GL6li.mrb7YSaMzXv9CEn8562XaUua5oNHbWi',NULL,3,1,'2025-12-03 17:47:58.034','2025-12-11 17:47:22.610',NULL,0,'2025-12-11 17:47:22.396','2025-12-11 18:02:22.396'),(5,'fgh',NULL,'gfh@gmail.com','$2b$10$rJO90cHoa3r8DZLKlbq27euHDGS.t4vvjPbZe1btCMcsz3rQoiL8.',1,2,1,'2025-12-03 17:50:55.715','2025-12-03 17:50:55.715',NULL,0,NULL,NULL),(6,'fgh',NULL,'gfkh@gmail.com','$2b$10$4SYtT1Assjmta4gMENjt6ODM2q5UVKOf7QQReZjSHacaKgYzWl.5q',1,2,1,'2025-12-03 17:57:30.003','2025-12-11 17:48:48.833',NULL,0,'2025-12-11 17:48:48.570','2025-12-11 18:03:48.570'),(7,'fgh',NULL,'fkh@gmail.com','$2b$10$JCbV1S1rhx1GbjSVN4MqqeRvj2U/h5lJVK0i4C.tuNBUF38mvJbs.',2,2,1,'2025-12-03 17:58:37.307','2025-12-11 17:55:50.900',NULL,0,'2025-12-11 17:55:50.681',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userrole` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserRole_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` VALUES (1,'SUPERADMIN','2025-11-30 12:51:08.190','2025-11-30 12:51:08.190',NULL),(2,'EMPLOYEE','2025-11-30 12:51:08.190','2025-11-30 12:51:08.190',NULL),(3,'CLIENT','2025-11-30 12:51:08.190','2025-11-30 12:51:08.190',NULL);
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrolepermission`
--

DROP TABLE IF EXISTS `userrolepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userrolepermission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userRoleId` int NOT NULL,
  `permissionId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `UserRolePermission_userRoleId_permissionId_idx` (`userRoleId`,`permissionId`),
  KEY `UserRolePermission_permissionId_fkey` (`permissionId`),
  CONSTRAINT `UserRolePermission_permissionId_fkey` FOREIGN KEY (`permissionId`) REFERENCES `permission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `UserRolePermission_userRoleId_fkey` FOREIGN KEY (`userRoleId`) REFERENCES `userrole` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrolepermission`
--

LOCK TABLES `userrolepermission` WRITE;
/*!40000 ALTER TABLE `userrolepermission` DISABLE KEYS */;
INSERT INTO `userrolepermission` VALUES (1,2,1,'2025-11-30 12:51:08.227','2025-11-30 12:51:08.227',NULL),(2,2,2,'2025-11-30 12:51:08.228','2025-11-30 12:51:08.228',NULL),(3,2,3,'2025-11-30 12:51:08.243','2025-11-30 12:51:08.243',NULL),(4,1,4,'2025-12-10 21:32:21.227','2025-12-10 21:32:21.227',NULL);
/*!40000 ALTER TABLE `userrolepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertoken`
--

DROP TABLE IF EXISTS `usertoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usertoken` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `fcmToken` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserToken_fcmToken_key` (`fcmToken`),
  KEY `UserToken_userId_fkey` (`userId`),
  CONSTRAINT `UserToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertoken`
--

LOCK TABLES `usertoken` WRITE;
/*!40000 ALTER TABLE `usertoken` DISABLE KEYS */;
INSERT INTO `usertoken` VALUES (1,2,'sdfghj','2025-12-03 17:49:18.751','2025-12-03 17:58:44.749',NULL),(2,1,'string','2025-12-10 21:43:31.112','2025-12-11 17:59:55.159',NULL);
/*!40000 ALTER TABLE `usertoken` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 11:14:56
